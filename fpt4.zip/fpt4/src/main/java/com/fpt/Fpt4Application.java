package com.fpt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fpt4Application {

	public static void main(String[] args) {
		SpringApplication.run(Fpt4Application.class, args);
	}
}
